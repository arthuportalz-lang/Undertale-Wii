#!/bin/bash

XDG_DATA_HOME=${XDG_DATA_HOME:-$HOME/.local/share}
# find libs or smth
if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
elif [ -d "$XDG_DATA_HOME/PortMaster/" ]; then
  controlfolder="$XDG_DATA_HOME/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt

get_controls
[ -f "${controlfolder}/mod_${CFW_NAME}.txt" ] && source "${controlfolder}/mod_${CFW_NAME}.txt"

GAMEDIR="/$directory/ports/balatro"

export XDG_DATA_HOME="$GAMEDIR/saves" # allowing saving to the same path as the game
export XDG_CONFIG_HOME="$GAMEDIR/saves"
export LD_LIBRARY_PATH="$GAMEDIR/libs.${DEVICE_ARCH}:$LD_LIBRARY_PATH"

mkdir -p "$XDG_DATA_HOME"
mkdir -p "$XDG_CONFIG_HOME"

> "$GAMEDIR/log.txt" && exec > >(tee "$GAMEDIR/log.txt") 2>&1

cd $GAMEDIR

$ESUDO chmod a+x ./bin/*

if [ -f "Balatro.exe" ]; then
    GAMEFILE="Balatro.exe"
elif [ -f "balatro.exe" ]; then
    GAMEFILE="balatro.exe"
elif [ -f "Balatro.love" ]; then
    GAMEFILE="Balatro.love"
elif [ -f "balatro.love" ]; then
    GAMEFILE="balatro.love"
fi
# create a working directory
if [ -f "$GAMEFILE" ]; then
  # Extract and modify globals.lua
  ./bin/7za.${DEVICE_ARCH} x "$GAMEFILE" globals.lua

  # change some default settings to maintain performance
  sed -i 's/crt = 70,/crt = 0,/g' globals.lua
  sed -i 's/bloom = 1/bloom = 0/g' globals.lua
  sed -i 's/shadows = 'On'/shadows = 'Off'/g' globals.lua
  sed -i 's/self.F_HIDE_BG = false/self.F_HIDE_BG = true/g' globals.lua

  # change controller mapping (swap A/B,X/Y to match the physical buttons) for TSP/BRICK.
  echo "Device Name: $DEVICE_NAME"
  if [ $DEVICE_NAME = "TRIMUI-BRICK" ] || [ $DEVICE_NAME = "TRIMUI-SMART-PRO" ] || [ $DEVICE_NAME = "trimui-smart-pro" ] || [ $DEVICE_NAME = "trimui-brick" ] || [ $DEVICE_NAME = "TrimUI Smart Pro" ] || [ $DEVICE_NAME = "TrimUI Brick" ] && [ $CFW_NAME != "muOS" ]; then
    sed -i 's/self.F_SWAP_AB_BUTTONS = false/self.F_SWAP_AB_BUTTONS = true/g' globals.lua
    sed -i 's/self.F_SWAP_XY_BUTTONS = false/self.F_SWAP_XY_BUTTONS = true/g' globals.lua
  fi

  # increase the scale for 640x480, following https://www.reddit.com/r/SBCGaming/comments/1e75wva/comment/mo5mkl2
  if [ $DISPLAY_WIDTH -eq 640 ] && [ $DISPLAY_HEIGHT -eq 480 ]; then 
    sed -i 's/self.TILESIZE = .*/self.TILESIZE = 40/g' globals.lua
    sed -i 's/self.TILESCALE = .*/self.TILESCALE = 5.65/g' globals.lua
    sed -i 's/self.TILE_W = .*/self.TILE_W = 20/g' globals.lua
    sed -i 's/self.TILE_H = .*/self.TILE_H = 15/g' globals.lua
    sed -i 's/self.DRAW_HASH_BUFF = .*/self.DRAW_HASH_BUFF = 2/g' globals.lua
    sed -i 's/self.CARD_W = .*/self.CARD_W = 2.7*35/41/g' globals.lua
    sed -i 's/self.CARD_H = .*/self.CARD_H = 2.7*47/41/g' globals.lua
    sed -i 's/self.HIGHLIGHT_H = .*/self.HIGHLIGHT_H = 0.2*self.CARD_H/g' globals.lua
    sed -i 's/self.COLLISION_BUFFER = .*/self.COLLISION_BUFFER = 0.03/g' globals.lua
    # Increase font size for everything 480p and below
    ./bin/7za.${DEVICE_ARCH} x "$GAMEFILE" game.lua
    sed -i 's/FONTSCALE = 0.1/FONTSCALE = 0.2' game.lua
    # sed -i 's/FONTSCALE = 0.12/FONTSCALE = 0.24/g' game.lua
    ./bin/7za.${DEVICE_ARCH} u -aoa "$GAMEFILE" game.lua
    rm game.lua
  fi

    # increase the scale for trimui brick
  if [ $DISPLAY_WIDTH -eq 1024 ] && [ $DISPLAY_HEIGHT -eq 768 ]; then 
    sed -i 's/self.TILESIZE = .*/self.TILESIZE = 40/g' globals.lua
    sed -i 's/self.TILESCALE = .*/self.TILESCALE = 5.65/g' globals.lua
    sed -i 's/self.TILE_W = .*/self.TILE_W = 20/g' globals.lua
    sed -i 's/self.TILE_H = .*/self.TILE_H = 15/g' globals.lua
    sed -i 's/self.DRAW_HASH_BUFF = .*/self.DRAW_HASH_BUFF = 2/g' globals.lua
    sed -i 's/self.CARD_W = .*/self.CARD_W = 2.7*35/41/g' globals.lua
    sed -i 's/self.CARD_H = .*/self.CARD_H = 2.7*47/41/g' globals.lua
    sed -i 's/self.HIGHLIGHT_H = .*/self.HIGHLIGHT_H = 0.2*self.CARD_H/g' globals.lua
    sed -i 's/self.COLLISION_BUFFER = .*/self.COLLISION_BUFFER = 0.03/g' globals.lua
  fi


  # even bigger, for ewaste!
  if [ $DISPLAY_WIDTH -lt 640 ] && [ $DISPLAY_HEIGHT -lt 480 ]; then
    ./bin/7za.${DEVICE_ARCH} x "$GAMEFILE" game.lua
    sed -i 's/FONTSCALE = 0.1/FONTSCALE = 0.25' game.lua
    # sed -i 's/FONTSCALE = 0.12/FONTSCALE = 0.3/g' game.lua
    ./bin/7za.${DEVICE_ARCH} u -aoa "$GAMEFILE" game.lua
    rm game.lua
  fi
  # big cards for ewaste
  if [ $DISPLAY_WIDTH -le 640 ] && [ $DISPLAY_HEIGHT -le 480 ]; then
    ./bin/7za.${DEVICE_ARCH} u -aoa "$GAMEFILE" resources/textures/1x/8BitDeck.png
    ./bin/7za.${DEVICE_ARCH} u -aoa "$GAMEFILE" resources/textures/1x/8BitDeck_opt2.png
    ./bin/7za.${DEVICE_ARCH} u -aoa "$GAMEFILE" resources/textures/2x/8BitDeck.png
    ./bin/7za.${DEVICE_ARCH} u -aoa "$GAMEFILE" resources/textures/2x/8BitDeck_opt2.png
  fi

  # None of this is needed on the rg34xxxsp the 720x480 makes nothing smaller since the game is basically 3:2 by default. With 4:3 some stuff is made smaller so allowing overlapping is needed.

  if [ $DISPLAY_WIDTH -le 1024 ]; then # switch out the font if the screen is too low res, or too small, makes it readable and the text doesn't shimmer anymore. Covers 720x720, brick, rg34xx and rg35xx
    cp resources/fonts/Nunito-Black.ttf resources/fonts/m6x11plus.ttf # change Nunito-Black to the in-game font file
    ./bin/7za.${DEVICE_ARCH} u -aoa "$GAMEFILE" resources/fonts/m6x11plus.ttf
    rm resources/fonts/m6x11plus.ttf
  fi

  # Update the archive with the modified globals.lua
  ./bin/7za.${DEVICE_ARCH} u -aoa "$GAMEFILE" globals.lua

  # RGB30 & Other 1x1 square ratio device specific changes
  if [ $DISPLAY_HEIGHT -eq $DISPLAY_WIDTH ]; then
    mkdir -p ./functions
    ./bin/7za.${DEVICE_ARCH} x "$GAMEFILE" functions/common_events.lua
    # move the hands a bit to the right
    sed -i 's/G.hand.T.x = G.TILE_W - G.hand.T.w - 2.85/G.hand.T.x = G.TILE_W - G.hand.T.w - 1/g' functions/common_events.lua
    # then move the playing area up
    sed -i 's/G.play.T.y = G.hand.T.y - 3.6/G.play.T.y = G.hand.T.y - 4.5/g' functions/common_events.lua
    # move the decks to the right
    sed -i 's/G.deck.T.x = G.TILE_W - G.deck.T.w - 0.5/G.deck.T.x = G.TILE_W - G.deck.T.w + 0.85/g' functions/common_events.lua
    # move the jokers to the left
    sed -i 's/G.jokers.T.x = G.hand.T.x - 0.1/G.jokers.T.x = G.hand.T.x - 0.2/g' functions/common_events.lua

    # Update the archive with the modified common_events.lua
    ./bin/7za.${DEVICE_ARCH} u -aoa "$GAMEFILE" functions/common_events.lua
    rm functions/common_events.lua
  fi
  # CP the file to Patched Balatro location
  cp $GAMEFILE Balatro

  rm $GAMEFILE
  rm globals.lua
fi

if [ $CFW_NAME = "TrimUI" ]; then
  # These libs are no good.
  # crossmix bad, I put in a PR to have these replaced on cross so it shouldn't be an issue in a bit of time all of these are new so idk what this guy was on about
  LIBDIR="$GAMEDIR/libs.${DEVICE_ARCH}"

  if [ -f "$LIBDIR/libfontconfig.so.1" ]; then
    $ESUDO rm -f "$LIBDIR/libfontconfig.so.1"
  fi

  if [ -f "$LIBDIR/libtheoradec.so.1" ]; then
    $ESUDO rm -f "$LIBDIR/libtheoradec.so.1"
  fi
fi

LAUNCH_GAME="Balatro"
if [ -f "$LAUNCH_GAME" ]; then
  if [ $DEVICE_RAM -gt 1 ]; then
    echo "Device has more than 1GB of RAM. Using Lovely."
    source $controlfolder/runtimes/love_11.5/love.txt
    $GPTOKEYB "love.${DEVICE_ARCH}" &
    pm_platform_helper "$LOVE_BINARY"
    LD_PRELOAD=$GAMEDIR/liblovely.so $LOVE_RUN "$LAUNCH_GAME" "$@"
  else
    # Device has 1GB of RAM or less
    echo "Device has 1GB of RAM or less. Running without LD_PRELOAD."
    source $controlfolder/runtimes/love_11.5/love.txt
    $GPTOKEYB "love.${DEVICE_ARCH}" &
    pm_platform_helper "$LOVE_BINARY"
    ./bin/love.armhf "$LAUNCH_GAME"
  fi
else
  echo "Balatro game file not found. Please drop in Balatro.exe or Balatro.love into the Balatro folder prior to starting the game."
fi

pm_finish
